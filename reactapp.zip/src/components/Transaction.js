import React from 'react';
import './Transaction.css';

const Transaction = () => {
  return (
    <div className="transaction">
      <h2>Transaction</h2>
      <div className="graph">[Graph Component]</div>
    </div>
  );
};

export default Transaction;
