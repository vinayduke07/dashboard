import React from 'react';
import './Announcement.css';

const Announcement = () => {
  return (
    <div className="announcement">
      <h2>Announcement</h2>
      <h4>CRYPTO</h4>
      <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. </p>
      <h4>CRYPTO</h4>
      <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
    </div>
  );
};

export default Announcement;
